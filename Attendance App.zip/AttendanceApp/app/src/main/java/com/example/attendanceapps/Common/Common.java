package com.example.attendanceapps.Common;

import com.example.attendanceapps.Models.EmployeeModel;

public class Common {
    public static EmployeeModel currentEmployee;
    public static String imageBase64;
    public static final String employeesNode = "app/employees", attendanceNode = "app/attendance", adminsNode = "app/admin";
}
